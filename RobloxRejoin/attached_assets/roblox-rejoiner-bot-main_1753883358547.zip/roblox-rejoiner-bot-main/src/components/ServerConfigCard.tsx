import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { useState } from "react";
import { Server, ExternalLink, Copy, Settings } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ServerConfig {
  placeId: string;
  vipServerCode: string;
  useVipServer: boolean;
  checkInterval: number;
}

interface ServerConfigCardProps {
  config: ServerConfig;
  onConfigChange: (config: ServerConfig) => void;
}

export function ServerConfigCard({ config, onConfigChange }: ServerConfigCardProps) {
  const [localConfig, setLocalConfig] = useState(config);
  const { toast } = useToast();

  const handleSave = () => {
    onConfigChange(localConfig);
    toast({
      title: "Configuration Saved",
      description: "Server configuration has been updated successfully.",
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: "Text has been copied to your clipboard.",
    });
  };

  const extractVipCode = (url: string) => {
    const match = url.match(/privateServerLinkCode=([a-zA-Z0-9]+)/);
    if (match) {
      setLocalConfig({ ...localConfig, vipServerCode: url });
      toast({
        title: "VIP Code Extracted",
        description: "VIP server code has been extracted from the URL.",
      });
    } else {
      toast({
        title: "Invalid URL",
        description: "Could not extract VIP server code from the URL.",
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="relative overflow-hidden bg-gradient-to-br from-card to-secondary/20 border-border/50">
      <div className="absolute inset-0 bg-gradient-to-br from-gaming-secondary/5 to-gaming-accent/5" />
      
      <div className="relative p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 rounded-lg bg-gaming-secondary/10 text-gaming-secondary">
            <Settings className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-semibold text-lg">Server Configuration</h3>
            <p className="text-sm text-muted-foreground">Manage your Roblox game settings</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* VIP Server Toggle */}
          <div className="flex items-center justify-between p-4 rounded-lg bg-muted/30">
            <div className="flex items-center gap-3">
              <Server className="w-4 h-4 text-gaming-secondary" />
              <div>
                <Label className="text-sm font-medium">Use VIP Server</Label>
                <p className="text-xs text-muted-foreground">Connect to a private server</p>
              </div>
            </div>
            <Switch
              checked={localConfig.useVipServer}
              onCheckedChange={(checked) => 
                setLocalConfig({ ...localConfig, useVipServer: checked })
              }
            />
          </div>

          {localConfig.useVipServer ? (
            <div className="space-y-3">
              <Label htmlFor="vipCode">VIP Server URL/Code</Label>
              <div className="flex gap-2">
                <Input
                  id="vipCode"
                  placeholder="https://www.roblox.com/games/... or direct code"
                  value={localConfig.vipServerCode}
                  onChange={(e) => setLocalConfig({ ...localConfig, vipServerCode: e.target.value })}
                  className="font-mono text-sm"
                />
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => copyToClipboard(localConfig.vipServerCode)}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
              {localConfig.vipServerCode.includes('http') && (
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => extractVipCode(localConfig.vipServerCode)}
                  >
                    Extract Code
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => window.open(localConfig.vipServerCode, '_blank')}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Open
                  </Button>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              <Label htmlFor="placeId">Place ID</Label>
              <Input
                id="placeId"
                placeholder="Enter Roblox Place ID"
                value={localConfig.placeId}
                onChange={(e) => setLocalConfig({ ...localConfig, placeId: e.target.value })}
                className="font-mono"
              />
            </div>
          )}

          <div className="space-y-3">
            <Label htmlFor="interval">Check Interval (seconds)</Label>
            <Input
              id="interval"
              type="number"
              min="1"
              max="60"
              value={localConfig.checkInterval}
              onChange={(e) => setLocalConfig({ ...localConfig, checkInterval: parseInt(e.target.value) || 5 })}
            />
          </div>

          <div className="flex gap-3 pt-4 border-t border-border/50">
            <Button onClick={handleSave} className="flex-1 bg-gaming-primary hover:bg-gaming-primary/80">
              Save Configuration
            </Button>
            <Button variant="outline" onClick={() => setLocalConfig(config)}>
              Reset
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}