import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Play, Square, RotateCcw, Monitor } from "lucide-react";

interface GameStatusCardProps {
  title: string;
  status: "online" | "offline" | "connecting";
  icon: React.ReactNode;
  description: string;
  onStart?: () => void;
  onStop?: () => void;
  onRestart?: () => void;
}

export function GameStatusCard({ 
  title, 
  status, 
  icon, 
  description, 
  onStart, 
  onStop, 
  onRestart 
}: GameStatusCardProps) {
  const getStatusColor = () => {
    switch (status) {
      case "online": return "bg-gaming-success";
      case "offline": return "bg-gaming-danger";
      case "connecting": return "bg-gaming-warning";
      default: return "bg-gaming-danger";
    }
  };

  const getStatusText = () => {
    switch (status) {
      case "online": return "Online";
      case "offline": return "Offline";
      case "connecting": return "Connecting";
      default: return "Unknown";
    }
  };

  return (
    <Card className="relative overflow-hidden bg-gradient-to-br from-card to-secondary/20 border-border/50 hover:border-gaming-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-gaming-primary/20">
      <div className="absolute inset-0 bg-gradient-to-br from-gaming-primary/5 to-gaming-secondary/5" />
      
      <div className="relative p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-gaming-primary/10 text-gaming-primary">
              {icon}
            </div>
            <div>
              <h3 className="font-semibold text-lg">{title}</h3>
              <p className="text-sm text-muted-foreground">{description}</p>
            </div>
          </div>
          
          <Badge 
            className={`${getStatusColor()} text-white font-medium px-3 py-1 animate-pulse-glow`}
          >
            {getStatusText()}
          </Badge>
        </div>

        <div className="flex gap-2">
          {status === "offline" && onStart && (
            <Button 
              size="sm" 
              className="bg-gaming-success hover:bg-gaming-success/80"
              onClick={onStart}
            >
              <Play className="w-4 h-4 mr-2" />
              Start
            </Button>
          )}
          
          {status === "online" && onStop && (
            <Button 
              size="sm" 
              variant="destructive"
              onClick={onStop}
            >
              <Square className="w-4 h-4 mr-2" />
              Stop
            </Button>
          )}
          
          {onRestart && (
            <Button 
              size="sm" 
              variant="outline"
              onClick={onRestart}
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Restart
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
}