import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { FileText, Download, Trash2 } from "lucide-react";

interface LogEntry {
  id: string;
  timestamp: Date;
  type: "info" | "success" | "warning" | "error";
  message: string;
  component?: string;
}

interface ActivityLogProps {
  logs: LogEntry[];
  onClearLogs: () => void;
}

export function ActivityLog({ logs, onClearLogs }: ActivityLogProps) {
  const getLogIcon = (type: string) => {
    switch (type) {
      case "success": return "✅";
      case "warning": return "⚠️";
      case "error": return "❌";
      default: return "ℹ️";
    }
  };

  const getLogColor = (type: string) => {
    switch (type) {
      case "success": return "text-gaming-success";
      case "warning": return "text-gaming-warning";
      case "error": return "text-gaming-danger";
      default: return "text-foreground";
    }
  };

  const exportLogs = () => {
    const logText = logs.map(log => 
      `[${log.timestamp.toLocaleString()}] ${log.type.toUpperCase()}: ${log.message}`
    ).join('\n');
    
    const blob = new Blob([logText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `roblox-manager-logs-${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Card className="flex flex-col h-full bg-gradient-to-br from-card to-secondary/20 border-border/50">
      <div className="flex items-center justify-between p-4 border-b border-border/50">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-gaming-accent/10 text-gaming-accent">
            <FileText className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-semibold">Activity Log</h3>
            <p className="text-sm text-muted-foreground">{logs.length} entries</p>
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={exportLogs}>
            <Download className="w-4 h-4" />
          </Button>
          <Button size="sm" variant="outline" onClick={onClearLogs}>
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <ScrollArea className="flex-1 p-4">
        <div className="space-y-2">
          {logs.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <FileText className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p>No activity yet</p>
              <p className="text-sm">Start the system to see logs</p>
            </div>
          ) : (
            logs.slice(-100).reverse().map((log) => (
              <div
                key={log.id}
                className="flex items-start gap-3 p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
              >
                <span className="text-lg leading-none">{getLogIcon(log.type)}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs text-muted-foreground font-mono">
                      {log.timestamp.toLocaleTimeString()}
                    </span>
                    {log.component && (
                      <Badge variant="outline" className="text-xs">
                        {log.component}
                      </Badge>
                    )}
                  </div>
                  <p className={`text-sm ${getLogColor(log.type)} break-words`}>
                    {log.message}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      </ScrollArea>
    </Card>
  );
}