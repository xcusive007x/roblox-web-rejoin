import { useState, useEffect } from "react";
import { GameStatusCard } from "@/components/GameStatusCard";
import { ServerConfigCard } from "@/components/ServerConfigCard";
import { ActivityLog } from "@/components/ActivityLog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Monitor, 
  Smartphone, 
  Gamepad2, 
  Play, 
  Square, 
  Settings,
  Zap,
  Clock,
  Users
} from "lucide-react";

interface LogEntry {
  id: string;
  timestamp: Date;
  type: "info" | "success" | "warning" | "error";
  message: string;
  component?: string;
}

const Index = () => {
  const { toast } = useToast();
  const [isSystemRunning, setIsSystemRunning] = useState(false);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  
  // Initialize with the provided configuration
  const [config, setConfig] = useState({
    placeId: "72829404259339",
    vipServerCode: "https://www.roblox.com/games/72829404259339/CSM-Anime-Rangers-X?privateServerLinkCode=27307107119063717961525965030253",
    useVipServer: true,
    checkInterval: 5
  });

  const [systemStatus, setSystemStatus] = useState({
    mumu: "offline" as "online" | "offline" | "connecting",
    adb: "offline" as "online" | "offline" | "connecting",
    roblox: "offline" as "online" | "offline" | "connecting"
  });

  const addLog = (type: LogEntry["type"], message: string, component?: string) => {
    const newLog: LogEntry = {
      id: Date.now().toString(),
      timestamp: new Date(),
      type,
      message,
      component
    };
    setLogs(prev => [...prev, newLog]);
  };

  const startSystem = () => {
    setIsSystemRunning(true);
    addLog("info", "🚀 Starting Roblox Auto Rejoin System", "System");
    
    // Simulate system startup
    setTimeout(() => {
      setSystemStatus(prev => ({ ...prev, mumu: "connecting" }));
      addLog("info", "Connecting to MuMu Player...", "MuMu");
      
      setTimeout(() => {
        setSystemStatus(prev => ({ ...prev, mumu: "online", adb: "connecting" }));
        addLog("success", "MuMu Player connected successfully", "MuMu");
        addLog("info", "Establishing ADB connection...", "ADB");
        
        setTimeout(() => {
          setSystemStatus(prev => ({ ...prev, adb: "online", roblox: "connecting" }));
          addLog("success", "ADB connection established", "ADB");
          addLog("info", "Launching Roblox...", "Roblox");
          
          setTimeout(() => {
            setSystemStatus(prev => ({ ...prev, roblox: "online" }));
            const serverType = config.useVipServer ? "VIP Server" : "Public Server";
            addLog("success", `Roblox launched successfully - Connected to ${serverType}`, "Roblox");
            addLog("info", `Monitoring system every ${config.checkInterval} seconds`, "System");
          }, 2000);
        }, 1500);
      }, 2000);
    }, 1000);

    toast({
      title: "System Started",
      description: "Roblox Auto Rejoin system is now active.",
    });
  };

  const stopSystem = () => {
    setIsSystemRunning(false);
    setSystemStatus({
      mumu: "offline",
      adb: "offline", 
      roblox: "offline"
    });
    addLog("warning", "⏹ System stopped by user", "System");
    
    toast({
      title: "System Stopped",
      description: "Roblox Auto Rejoin system has been stopped.",
    });
  };

  const restartComponent = (component: string) => {
    addLog("info", `Restarting ${component}...`, component);
    setSystemStatus(prev => ({ ...prev, [component.toLowerCase()]: "connecting" }));
    
    setTimeout(() => {
      setSystemStatus(prev => ({ ...prev, [component.toLowerCase()]: "online" }));
      addLog("success", `${component} restarted successfully`, component);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/20">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-gaming-primary to-gaming-secondary animate-float">
              <Gamepad2 className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-gaming-primary to-gaming-secondary bg-clip-text text-transparent">
                Roblox Game Manager
              </h1>
              <p className="text-muted-foreground">Made by x_Cusive ตึงมาก❤️</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <Badge variant={isSystemRunning ? "default" : "secondary"} className="px-3 py-1">
              <Zap className="w-3 h-3 mr-1" />
              {isSystemRunning ? "System Active" : "System Idle"}
            </Badge>
            <Badge variant="outline" className="px-3 py-1">
              <Clock className="w-3 h-3 mr-1" />
              Check Interval: {config.checkInterval}s
            </Badge>
            <Badge variant="outline" className="px-3 py-1">
              <Users className="w-3 h-3 mr-1" />
              {config.useVipServer ? "VIP Server" : "Public Server"}
            </Badge>
          </div>
        </div>

        {/* Control Panel */}
        <Card className="mb-6 p-6 bg-gradient-to-r from-gaming-primary/10 to-gaming-secondary/10 border-gaming-primary/20">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold mb-1">System Control</h2>
              <p className="text-muted-foreground">Start, stop, and monitor your Roblox automation</p>
            </div>
            <div className="flex gap-3">
              {!isSystemRunning ? (
                <Button 
                  onClick={startSystem}
                  size="lg"
                  className="bg-gaming-success hover:bg-gaming-success/80 shadow-lg hover:shadow-gaming-success/20"
                >
                  <Play className="w-5 h-5 mr-2" />
                  Start System
                </Button>
              ) : (
                <Button 
                  onClick={stopSystem}
                  size="lg"
                  variant="destructive"
                  className="shadow-lg"
                >
                  <Square className="w-5 h-5 mr-2" />
                  Stop System
                </Button>
              )}
            </div>
          </div>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Status Cards */}
          <div className="lg:col-span-2 space-y-6">
            {/* Status Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <GameStatusCard
                title="MuMu Player"
                status={systemStatus.mumu}
                icon={<Monitor className="w-5 h-5" />}
                description="Android Emulator"
                onRestart={() => restartComponent("MuMu")}
              />
              
              <GameStatusCard
                title="ADB Connection"
                status={systemStatus.adb}
                icon={<Smartphone className="w-5 h-5" />}
                description="Device Bridge"
                onRestart={() => restartComponent("ADB")}
              />
              
              <GameStatusCard
                title="Roblox"
                status={systemStatus.roblox}
                icon={<Gamepad2 className="w-5 h-5" />}
                description="Game Client"
                onRestart={() => restartComponent("Roblox")}
              />
            </div>

            {/* Server Configuration */}
            <ServerConfigCard 
              config={config}
              onConfigChange={setConfig}
            />
          </div>

          {/* Right Column - Activity Log */}
          <div className="h-[600px]">
            <ActivityLog 
              logs={logs}
              onClearLogs={() => {
                setLogs([]);
                toast({
                  title: "Logs Cleared",
                  description: "Activity log has been cleared.",
                });
              }}
            />
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 pt-6 border-t border-border/50 text-center text-muted-foreground">
          <p>🎮 Roblox Game Manager - Automated game session management</p>
          <p className="text-sm mt-1">Built with React, TypeScript, and Tailwind CSS</p>
        </div>
      </div>
    </div>
  );
};

export default Index;